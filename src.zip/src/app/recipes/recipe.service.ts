import { Recipe } from './recipe.model';

import { EventEmitter, Injectable } from '@angular/core';
import { Ingredient } from '../shared/ingredient.model';
import { ShoppingListService } from '../shopping-list/shopping-list.service';

@Injectable()
export class RecipeService{

    recipeSelected = new EventEmitter<Recipe>();

    constructor(private shoppingListService: ShoppingListService) {

    }
    
    private recipes: Recipe[]=[
        new Recipe('Channa Masala',
        'Recipe to prepare Channa Masala',
        'https://cookieandkate.com/images/2020/03/vegan-chana-masala-recipe-2.jpg',
        [new Ingredient('Channa',1),
        new Ingredient('Tomato',2),
        new Ingredient('Coriander',1)]
        ),
        new Recipe('Poori',
        'Recipe to prepare Poori',
        'https://thumbs.dreamstime.com/b/poori-saagu-delicious-deep-fried-puri-served-spicy-potato-onion-curry-chutney-44382859.jpg',
        [new Ingredient('Wheat flour',2),
        new Ingredient('Oil',1)]
        )
      ];

    getRecipes(){
        return this.recipes.slice();
    }

    addIngredientsToShoppingListService(ingredients: Ingredient[]){
        this.shoppingListService.addRecipeIngredientsToShoppingList(ingredients);
    }

}