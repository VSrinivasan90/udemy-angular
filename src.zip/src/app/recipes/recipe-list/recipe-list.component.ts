import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Recipe } from '../recipe.model';
import { RecipeService } from '../recipe.service';

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {

  //@Output('recipeItemFromList') outputRecipeItemFromList = new EventEmitter<Recipe>();

  /*recipes: Recipe[]=[
    new Recipe('1st Test Recipe','This is the 1st test Recipe','https://cookieandkate.com/images/2020/03/vegan-chana-masala-recipe-2.jpg'),
    new Recipe('2nd Test Recipe','This is the 2nd test Recipe','https://cookieandkate.com/images/2020/03/vegan-chana-masala-recipe-2.jpg')
  ];*/

  recipes: Recipe[]=[]; 

  constructor(private recipeService: RecipeService) { }

  ngOnInit(): void {
    this.recipes=this.recipeService.getRecipes();
  }

  /*listenRecipeItem(listenedRecipeItem: Recipe){
    console.log("listenedRecipeItem in List...",listenedRecipeItem);
    this.outputRecipeItemFromList.emit(listenedRecipeItem);
  }*/



}
