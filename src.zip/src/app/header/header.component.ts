import { Component,
    EventEmitter,
    Output } from '@angular/core';

@Component({
    'selector' : 'app-header',
    'templateUrl' : './header.component.html',
    'styleUrls': ['./header.component.css']
})
export class HeaderComponent{

    @Output('selHeader') selectedHeader= new EventEmitter<string>();
    headerOption: string='';

    chooseRecipeOrShopping(event: Event){
       // console.log("event...",event);
        this.headerOption = (<HTMLAnchorElement>event.srcElement).innerText;
       // console.log("headeroption...",this.headerOption);
        return this.selectedHeader.emit((<HTMLAnchorElement>event.srcElement).innerText);
    }

}