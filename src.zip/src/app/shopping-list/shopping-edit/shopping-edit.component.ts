import { Component, 
        OnInit, 
        ViewChild,
        ElementRef,
        EventEmitter, 
        Output} from '@angular/core';
import { Ingredient } from '../../shared/ingredient.model';
import { ShoppingListService } from '../shopping-list.service';

@Component({
  selector: 'app-shopping-edit',
  templateUrl: './shopping-edit.component.html',
  styleUrls: ['./shopping-edit.component.css']
})
export class ShoppingEditComponent implements OnInit {

  //ingredientToAdd: Ingredient;
  @ViewChild('nameInput',{static:true}) inputName: ElementRef;
  @ViewChild('amountInput',{static:true}) inputAmount: ElementRef;
  //@Output() ingredientAdded = new EventEmitter<Ingredient>();

  constructor(private shoppingListService: ShoppingListService) { }

  ngOnInit(): void {
  }

  onIngredientAdd(event: Event){
    console.log("input name value...",this.inputName.nativeElement.value);
    console.log("input amount value...",this.inputAmount.nativeElement.value);
    //this.ingredientToAdd.name=this.inputName.nativeElement.value;
    //this.ingredientToAdd.amount=this.inputAmount.nativeElement.value;
    /*this.ingredientAdded.emit(new Ingredient(this.inputName.nativeElement.value,
                                  this.inputAmount.nativeElement.value));*/
    /*this.shoppingListService.addIngredients(new Ingredient(this.inputName.nativeElement.value,
                                            this.inputAmount.nativeElement.value));*/
    this.shoppingListService.addIngredients(new Ingredient(this.inputName.nativeElement.value,
                                                      this.inputAmount.nativeElement.value));
                                                      
  }

}
