import { Ingredient } from '../shared/ingredient.model';
import { EventEmitter } from '@angular/core';

export class ShoppingListService{

    newIngredientAdded = new EventEmitter<Ingredient[]>();

    private ingredients: Ingredient[] =[
        new Ingredient('Apples',5),
        new Ingredient('Tomatoes',10)
      ];

    getIngredients(){
        return this.ingredients.slice();
        //return this.ingredients;
    }

    addIngredients(ingredient: Ingredient){
        this.ingredients.push(ingredient); // when ingredients array is not sliced
        this.newIngredientAdded.emit(this.ingredients.slice()); // when ingredients array is sliced
    }

    addRecipeIngredientsToShoppingList(ingredients: Ingredient[]){
        for(var i=0;i<ingredients.length;i++){
            this.ingredients.push(ingredients[i]);
        }
        this.newIngredientAdded.emit(this.ingredients.slice());
    }
 
}