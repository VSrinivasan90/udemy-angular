import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'course-pro';
  headerOption = 'Recipes';

  headerSelected(event: Event){
   // console.log("app event...",event);
    this.headerOption = <string><unknown>event;
  }
}
